#if !defined(__STDC_VERSION__) || !(__STDC_VERSION__ >= 199901L)
# error C99 compiler required.
#endif

#ifndef LUA_VERSION_NUM
# error Lua >= 5.1 is required.
#endif
