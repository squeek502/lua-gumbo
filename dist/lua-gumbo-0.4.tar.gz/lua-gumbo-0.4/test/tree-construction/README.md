This is a snapshot of the `tree-construction` directory of the
[html5lib test suite], minus the `scripted` sub-directory, at commit
`e633ddfeb0180f71238763576b1f5fdd26a7038f`.

[html5lib test suite]: https://github.com/html5lib/html5lib-tests
