require "luacov"
dofile "test/misc.lua"
dofile "test/dom.lua"
